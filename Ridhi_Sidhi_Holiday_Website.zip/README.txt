RIDHI SIDHI HOLIDAY - WEBSITE PROTOTYPE

Open index.html in Chrome/Safari to view the website.

This version includes:
- Chandigarh -> Ujjain search
- 40-seat AC seater layout
- Seat selection and fare calculation
- Passenger booking demo
- Tour package section
- Contact numbers

For a real public website, connect:
1. Domain + hosting
2. Bus booking database/admin panel
3. Payment gateway (UPI/cards)
4. SMS/WhatsApp confirmation
5. Real PNR/ticket generation
6. Cancellation/refund rules
